#!/bin/bash
#
# Universidade Federal de Minas Gerais
# Laboratório de Sistemas Digitais
# Autor: Prof. Ricardo de Oliveira Duarte - DELT/EE/UFMG
# Compilation and Simulation with GHDL Batch File - versão 1.0
# Referência: https://www.windowscentral.com/how-create-and-run-batch-file-windows-10
# Objetivos:
# (1) Analisar arquivos .vhd usando GHDL
# (2) Simular arquivos .vhd usando GHDL
# (3) Gerar arquivos com os resultados da simulação demandados pelo tb_funcao.vhd
# Pré-requisitos:
# (1) GHDL e GTKWAVE instalados
# (2) Variável de ambiente Path editada e ativada, com os caminhos dos executáveis GHDL e GTKWAVE
# Para executar esse script:
# (1) Da janela Terminal (do MS-Windows ou do Visual Studion Code) digite no diretório onde se encontra o arquivo com extensão .bat o comando ".\batch_file_ghdl.bat"
#
# Modifique a linha abaixo para o caminho do seu computador onde se encontra os seus arquivos fonte a serem compilados e simulados.
#cd /home/ricardo/LAOC/Batch_scripts_e_TCL_scripts/LSD_guia_10_ERE_codigos
# UNIT="$1"
# echo -e "\033[1mChecking syntax..\033[0m\n"
# ghdl -s "$UNIT".vhd tb_"$UNIT".vhd
# echo -e "\033[1mAnalyzing files..\033[0m\n"
# ghdl -a "$UNIT".vhd tb_"$UNIT".vhd
# echo -e "\033[1mElaborating unit..\033[0m\n"
# ghdl -e tb_"$UNIT"
# echo -e "\033[1mRun unit and dumping signal values..\033[0m\n"
# ghdl -r tb_"$UNIT" --vcd=tb_"$UNIT".vcd
# echo -e "\033[1mStarting waveform viewer..\033[0m\n"
# gtkwave --rcvar 'do_initial_zoom_fit yes' --rcvar 'hier_max_level 0' --rcvar 'splash_disable on' tb_"$UNIT".vcd
# echo -e "\033[1mDone.\033[0m"
# exit 0
ghdl -a funcao.vhd
ghdl -a tb_funcao.vhd
ghdl -e tb_funcao
ghdl -r tb_funcao
#:Done
